package com.example.OnlineFoodOrder.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.OnlineFoodOrder.DTO.BookingsByPrize;
import com.example.OnlineFoodOrder.DTO.RestaurantAndItemVO;
import com.example.OnlineFoodOrder.Service.RestaurantInfoService;
import com.example.OnlineFoodOrder.entity.BookingOrder;
import com.example.OnlineFoodOrder.entity.ItemCatalogue;
import com.example.OnlineFoodOrder.entity.OrderItem;
import com.example.OnlineFoodOrder.entity.Restaurant;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class RestaurantController {
	@Autowired
	private RestaurantInfoService restaurantInfoService;
	
	ObjectMapper objectMapper = new ObjectMapper();
	@RequestMapping(value = "/addItem", method = RequestMethod.POST)
	public ItemCatalogue addItem(@RequestBody ItemCatalogue item)
	{
		System.out.println("item ::"+item);
		return restaurantInfoService.addItemInCatalogue(item);
	}
	
	@RequestMapping(value = "/addRestaurant", method = RequestMethod.POST)
	public Restaurant addRestaurant(@RequestBody Restaurant restaurant)
	{
		System.out.println("restaurant ::"+restaurant);
		return restaurantInfoService.addRestaurant(restaurant);
	}
	
	@RequestMapping(value = "/getDestinationFromOigin", method = RequestMethod.POST)
	public List<Restaurant> getRestaurant(@RequestBody Restaurant restaurant)
	{
		System.out.println("restaurant ::"+restaurant);
		return restaurantInfoService.getRestaurantFromOrigin(restaurant);
	}
	
	@RequestMapping(value = "/bookingOrder", method = RequestMethod.POST)
	public void addBookingOrder(@RequestParam(value = "booking", required = true) String bookingData,@RequestParam(value = "order", required = true) String orderData)
	{
		try {
			BookingOrder booking = objectMapper.readValue(bookingData, BookingOrder.class);
			OrderItem order = objectMapper.readValue(orderData, OrderItem.class);
			System.out.println("doBookingOrder booking ::"+booking);
			restaurantInfoService.bookingItem(booking,order);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@RequestMapping(value = "/updateBookingOrder", method = RequestMethod.POST)
	public void updateBookingOrder(@RequestParam(value = "booking", required = true) String bookingData,@RequestParam(value = "order", required = true) String orderData)
	{
		try {
			BookingOrder booking = objectMapper.readValue(bookingData, BookingOrder.class);
			OrderItem order = objectMapper.readValue(orderData, OrderItem.class);
			System.out.println("update BookingOrder booking ::"+booking);
			restaurantInfoService.updateBookingItem(booking,order);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@RequestMapping(value = "/deleteBookingOrder", method = RequestMethod.POST)
	public void deleteBookingOrder(@RequestBody OrderItem order)//Param(value = "order", required = true) String orderData)
	{
		try {
			//OrderItem order = objectMapper.readValue(orderData, OrderItem.class);
			System.out.println("delete BookingOrder order ::"+order);
			restaurantInfoService.deleteBookingItem(order);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@RequestMapping(value = "/getAllBookings", method = RequestMethod.GET)
	public List<BookingOrder> getAllBookingOrder()
	{
			System.out.println("getAllBookingOrder ::");
			return restaurantInfoService.getAllBookings();
	}
	
	
	
	@RequestMapping(value = "/getItemsByPrice", method = RequestMethod.POST)
	public List<RestaurantAndItemVO> getItemsByPrice(@RequestParam(value="price") int price,@RequestParam(value = "rating") int rating)
	{
			System.out.println("price ::"+price+"[rating]"+rating);
			return restaurantInfoService.getRestaurantsByRating(price,rating);
	}
	
	@RequestMapping(value = "/getRestaurantByRegion", method = RequestMethod.POST)
	public List<Restaurant> getRestaurantsByRegion(@RequestBody Restaurant restaurant)
	{
			return restaurantInfoService.getRestaurantsByRegion(restaurant.getRegion());
	}
	
	@RequestMapping(value = "/priceWiseBooking", method = RequestMethod.GET)
	public List<BookingsByPrize> getBookingsByPrize()
	{
			return restaurantInfoService.getBookingsByPrize();
	}

}
