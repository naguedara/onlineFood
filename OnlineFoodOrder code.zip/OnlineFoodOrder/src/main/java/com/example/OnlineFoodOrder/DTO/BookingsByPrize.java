package com.example.OnlineFoodOrder.DTO;

public class BookingsByPrize {
	private int bookings;
	private int price;
	public int getBookings() {
		return bookings;
	}
	public void setBookings(int bookings) {
		this.bookings = bookings;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "BookingsByPrize [bookings=" + bookings + ", price=" + price + "]";
	}
	
	

}
