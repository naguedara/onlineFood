package com.example.OnlineFoodOrder.DAO.impl;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.OnlineFoodOrder.DAO.RestaurantServiceDAO;
import com.example.OnlineFoodOrder.DTO.BookingsByPrize;
import com.example.OnlineFoodOrder.DTO.RestaurantAndItemVO;
import com.example.OnlineFoodOrder.entity.Restaurant;
import com.example.OnlineFoodOrder.repo.RestaurantRepository;

@Repository
public class RestaurantServiceDAOImpl implements RestaurantServiceDAO {
	@Autowired
	private EntityManager entityManager;
	
	@Autowired
	private RestaurantRepository RestaurantRepo;

	@Override
	public List<RestaurantAndItemVO> getRestaurantsByRating(int price,int rating) {
		// TODO Auto-generated method stub
		List<RestaurantAndItemVO> searchContent = new ArrayList<RestaurantAndItemVO>();
		List<Object[]> objectVal = RestaurantRepo.searchByRatingAndPrive(rating, price);
		if(!objectVal.isEmpty()&&objectVal.size()>0)
		{
		for (Object[] obj : objectVal) {
			RestaurantAndItemVO item = new RestaurantAndItemVO();
			if(obj[1]!=null)
			{
				item.setName((String)obj[1]);
			}
			if(obj[2]!=null)
			{
				item.setRegion((String)obj[2]);
			}
			if(obj[3]!=null)
			{
				item.setRating((int)obj[3]);
			}
			if(obj[4]!=null)
			{
				item.setItemId((int)obj[4]);
			}
			if(obj[5]!=null)
			{
				item.setItemType((String)obj[5]);
			}
			if(obj[6]!=null)
			{
				item.setItemFamily((String)obj[6]);
			}
			if(obj[7]!=null)
			{
				item.setItemName((String)obj[7]);
			}
			if(obj[8]!=null)
			{
				item.setItemPrice((int)obj[8]);
			}
			if(obj[9]!=null)
			{
				item.setRestaurantId((int)obj[9]);
			}
			searchContent.add(item);
		}
		return searchContent;
		}
		else 
			return searchContent;
	}

	@Override
	public List<Restaurant> getRestaurantsByRegionWise(String region) {
		// TODO Auto-generated method stub
		System.out.println("region ::" + region);
		Session session = entityManager.unwrap(Session.class);
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Restaurant> query = builder.createQuery(Restaurant.class);
		Root<Restaurant> root = query.from(Restaurant.class);
		List<Predicate> predicates = new ArrayList<Predicate>();
		Predicate titleSearch = builder.equal(root.get("region"), region);
		predicates.add(builder.or(titleSearch));
		query.select(root).where(predicates.toArray(new Predicate[] {}));
		List<Restaurant> successStoryList = session.createQuery(query).getResultList();
		return successStoryList;
	}

	@Override
	public List<BookingsByPrize> groupByPrizeForBooking() {
		// TODO Auto-generated method stub
		List<BookingsByPrize> searchContent = new ArrayList<BookingsByPrize>();
		List<Object[]> objectVal = RestaurantRepo.bookingsByPrize();
		if(!objectVal.isEmpty()&&objectVal.size()>0)
		{
		for (Object[] obj : objectVal) {
			BookingsByPrize item = new BookingsByPrize();
			if(obj[0]!=null)
			{	
				item.setBookings((int)obj[1]);
			}
			if(obj[1]!=null)
			{
				item.setPrice((int)obj[1]);
			}
			searchContent.add(item);
		}
		return searchContent;
		}
		return searchContent;
	}

}
