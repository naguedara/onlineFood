package com.example.OnlineFoodOrder.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.OnlineFoodOrder.entity.ItemCatalogue;

public interface ItemCatalogueRepository extends JpaRepository<ItemCatalogue, Integer>{

}
