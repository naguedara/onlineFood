package com.example.OnlineFoodOrder.entity;
import javax.persistence.*;
@Entity
@Table(name = "booking")
public class BookingOrder {
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name="booking_by")
    private String bookingBy;
    @Column(name="item_id")
    private int itemId;
    @Column(name="total_price")
    private int totalPrice;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "order_id")
    private OrderItem order;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBookingBy() {
		return bookingBy;
	}
	public void setBookingBy(String bookingBy) {
		this.bookingBy = bookingBy;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public OrderItem getOrder() {
		return order;
	}
	public void setOrder(OrderItem order) {
		this.order = order;
	}
	public int getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice) {
		this.totalPrice = totalPrice;
	}
	@Override
	public String toString() {
		return "BookingOrder [id=" + id + ", bookingBy=" + bookingBy + ", itemId=" + itemId + ", totalPrice="
				+ totalPrice + ", order=" + order + "]";
	}
  
    
  }
