package com.example.OnlineFoodOrder.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.OnlineFoodOrder.entity.OrderItem;

public interface OrderRepository extends JpaRepository<OrderItem, Integer>{
	


}
