package com.example.OnlineFoodOrder.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.OnlineFoodOrder.entity.Restaurant;

public interface RestaurantRepository extends JpaRepository<Restaurant,Integer>{
	
	@Query(value = "SELECT * from restaurant where region=:region", nativeQuery = true)
	public List<Object[]> fetchRestaurantsByRegion(@Param("region") String region);
	
	@Query(value ="select * from restaurant r,item_catalougue i where i.item_price<=:price and i.restaurant_id=r.id and r.rating=:rating", nativeQuery = true)
	public List<Object[]> searchByRatingAndPrive(@Param("rating") int rating,@Param("price") int price);
	
	@Query(value ="select count(id) as number_of_bookings,total_price from booking  group by total_price", nativeQuery = true)
	public List<Object[]> bookingsByPrize();

}
