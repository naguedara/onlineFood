package com.example.OnlineFoodOrder.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.OnlineFoodOrder.entity.BookingOrder;
import com.example.OnlineFoodOrder.entity.OrderItem;

public interface BookingOrderRepository extends JpaRepository<BookingOrder, Integer>{
	
	//Optional<BookingOrder> findByIdAndPostId(Integer id, Integer postId);
	
	@Query(value = "delete from booking where order_id=:orderId", nativeQuery = true)
	public void deleteBooking(@Param("orderId") Integer orderId);

}
