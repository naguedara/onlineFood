package com.example.OnlineFoodOrder.DAO;

import java.util.List;

import com.example.OnlineFoodOrder.DTO.BookingsByPrize;
import com.example.OnlineFoodOrder.DTO.RestaurantAndItemVO;
import com.example.OnlineFoodOrder.entity.Restaurant;

public interface RestaurantServiceDAO {
	public List<RestaurantAndItemVO> getRestaurantsByRating(int price,int rating);

	public List<Restaurant> getRestaurantsByRegionWise(String region);

	public List<BookingsByPrize> groupByPrizeForBooking();

}
