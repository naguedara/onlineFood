package com.example.OnlineFoodOrder.DTO;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class RestaurantAndItemVO {
	private int itemId;
	private String itemFamily;
	private String itemType;
	private String itemName;
	private int itemPrice;
	private int restaurantId;
	private String name;
	private int rating;
	private String region;
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemFamily() {
		return itemFamily;
	}
	public void setItemFamily(String itemFamily) {
		this.itemFamily = itemFamily;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}
	public int getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(int restaurantId) {
		this.restaurantId = restaurantId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	@Override
	public String toString() {
		return "RestaurantAndItemVO [itemId=" + itemId + ", itemFamily=" + itemFamily + ", itemType=" + itemType
				+ ", itemName=" + itemName + ", itemPrice=" + itemPrice + ", restaurantId=" + restaurantId + ", name="
				+ name + ", rating=" + rating + ", region=" + region + "]";
	}
	
	

}
