package com.example.OnlineFoodOrder.Service;

import java.util.List;

import com.example.OnlineFoodOrder.DTO.BookingsByPrize;
import com.example.OnlineFoodOrder.DTO.RestaurantAndItemVO;
import com.example.OnlineFoodOrder.entity.BookingOrder;
import com.example.OnlineFoodOrder.entity.ItemCatalogue;
import com.example.OnlineFoodOrder.entity.OrderItem;
import com.example.OnlineFoodOrder.entity.Restaurant;

public interface RestaurantInfoService {
	public ItemCatalogue addItemInCatalogue(ItemCatalogue item);

	public Restaurant addRestaurant(Restaurant restaurant);

	public List<Restaurant> getRestaurantFromOrigin(Restaurant restaurant);

	public void bookingItem(BookingOrder booking,OrderItem orderVal);

	public void updateBookingItem(BookingOrder booking, OrderItem order);

	public void deleteBookingItem(OrderItem order);

	public List<BookingOrder> getAllBookings();

	public BookingOrder getBooking(BookingOrder booking);

	public List<RestaurantAndItemVO> getRestaurantsByRating(int price,int rating);

	public List<Restaurant> getRestaurantsByRegion(String region);

	public List<BookingsByPrize> getBookingsByPrize();

}
