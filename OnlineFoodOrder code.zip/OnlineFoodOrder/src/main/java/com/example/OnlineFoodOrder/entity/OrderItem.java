package com.example.OnlineFoodOrder.entity;
import javax.persistence.*;
@Entity
@Table(name = "order_item")
public class OrderItem {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name="id")
private int id;
@Column(name="payment_type")
private String orderPaymentType;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getOrderPaymentType() {
	return orderPaymentType;
}
public void setOrderPaymentType(String orderPaymentType) {
	this.orderPaymentType = orderPaymentType;
}
@Override
public String toString() {
	return "OrderItem [id=" + id + ", orderPaymentType=" + orderPaymentType + "]";
}


}
