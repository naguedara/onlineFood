package com.example.OnlineFoodOrder.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="item_catalougue")
public class ItemCatalogue {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="item_id")
	private int itemId;
	@Column(name="item_family")
	private String itemFamily;
	@Column(name="item_type")
	private String itemType;
	@Column(name="item_name")
	private String itemName;
	@Column(name="item_price")
	private int itemPrice;
	@Column(name="restaurant_id")
	private int restaurantId;
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemFamily() {
		return itemFamily;
	}
	public void setItemFamily(String itemFamily) {
		this.itemFamily = itemFamily;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}
	public int getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(int restaurantId) {
		this.restaurantId = restaurantId;
	}
	@Override
	public String toString() {
		return "ItemCatalogue [itemId=" + itemId + ", itemFamily=" + itemFamily + ", itemType=" + itemType
				+ ", itemName=" + itemName + ", itemPrice=" + itemPrice + ", restaurantId=" + restaurantId + "]";
	}
	
	
	


}
