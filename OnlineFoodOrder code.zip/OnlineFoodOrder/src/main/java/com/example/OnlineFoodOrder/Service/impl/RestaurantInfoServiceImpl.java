package com.example.OnlineFoodOrder.Service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.OnlineFoodOrder.DAO.RestaurantServiceDAO;
import com.example.OnlineFoodOrder.DTO.BookingsByPrize;
import com.example.OnlineFoodOrder.DTO.RestaurantAndItemVO;
import com.example.OnlineFoodOrder.Service.RestaurantInfoService;
import com.example.OnlineFoodOrder.entity.BookingOrder;
import com.example.OnlineFoodOrder.entity.ItemCatalogue;
import com.example.OnlineFoodOrder.entity.OrderItem;
import com.example.OnlineFoodOrder.entity.Restaurant;
import com.example.OnlineFoodOrder.repo.BookingOrderRepository;
import com.example.OnlineFoodOrder.repo.ItemCatalogueRepository;
import com.example.OnlineFoodOrder.repo.OrderRepository;
import com.example.OnlineFoodOrder.repo.RestaurantRepository;

@Service
public class RestaurantInfoServiceImpl implements RestaurantInfoService{

	@Autowired
	private ItemCatalogueRepository itemCatalogueRepo;
	@Autowired
	private RestaurantRepository restaurantRepo;
	@Autowired
	private OrderRepository orderRepo;
	@Autowired
	private BookingOrderRepository bookingOrder;
	@Autowired
	private EntityManager entityManager;
	
	@Autowired
	private RestaurantServiceDAO restaurantServiceDAO;
	
	@Override
	public ItemCatalogue addItemInCatalogue(ItemCatalogue item) {
		// TODO Auto-generated method stub
		return itemCatalogueRepo.save(item);
	}
	@Override
	public Restaurant addRestaurant(Restaurant restaurant) {
		// TODO Auto-generated method stub
		return restaurantRepo.save(restaurant);
	}
	@Override
	public List<Restaurant> getRestaurantFromOrigin(Restaurant restaurant) {
		// TODO Auto-generated method stub
		List<Object[]> objList = restaurantRepo.fetchRestaurantsByRegion(restaurant.getRegion());
		List<Restaurant> restaurants = new ArrayList<Restaurant>();
		if(!objList.isEmpty()&&objList.size()>0)
		{
		for (Object[] obj : objList) {
			Restaurant restaurantObj = new Restaurant();
			if(obj[0]!=null)
				restaurantObj.setRestaurantId((Integer)obj[0]);
			if(obj[1]!=null)
				restaurantObj.setName((String) obj[1]);
			if(obj[2]!=null)
				restaurantObj.setRating((Integer)(obj[2]));
			if(obj[3]!=null)
				restaurantObj.setRegion(obj[3].toString());
			
			restaurants.add(restaurantObj);
		}
	}
		return restaurants;
	}
	@Override
	public void bookingItem(BookingOrder booking,OrderItem orderVal) {
		// TODO Auto-generated method stub
		BookingOrder bookingObj = new BookingOrder();
		OrderItem order = new OrderItem();
		order.setOrderPaymentType(orderVal.getOrderPaymentType());
		orderRepo.save(order);
		System.out.println("Order saved");
		bookingObj.setBookingBy(booking.getBookingBy());
		bookingObj.setItemId(booking.getItemId());
		bookingObj.setOrder(order);
		bookingObj.setTotalPrice(booking.getTotalPrice());
		bookingOrder.save(bookingObj);
	
	}
	@Override
	public void updateBookingItem(BookingOrder booking, OrderItem order) {
		// TODO Auto-generated method stub
				BookingOrder bookingObj = new BookingOrder();
				System.out.println("Order1 "+order);
				OrderItem orderData = new OrderItem();
				Optional<OrderItem> orderDataObj = orderRepo.findById(order.getId());
				if(orderDataObj!=null)
				{
					orderData = orderDataObj.get();
				}
				if(order.getOrderPaymentType()!=null)
					orderData.setOrderPaymentType(order.getOrderPaymentType());
				orderRepo.save(orderData);
				System.out.println("Order saved"+orderData);
				Optional<BookingOrder> bookingDataObj = bookingOrder.findById(booking.getId());
				if(bookingDataObj!=null)
				{
					bookingObj = bookingDataObj.get();
				}
				if(booking.getBookingBy()!=null)
					bookingObj.setBookingBy(booking.getBookingBy());
				if(booking.getItemId()!=0)
					bookingObj.setItemId(booking.getItemId());
				if(booking.getTotalPrice()!=0)
					bookingObj.setTotalPrice(booking.getTotalPrice());		
				bookingObj.setOrder(orderData);
				bookingOrder.save(bookingObj);
		
	}
	@Override
	@Transactional
	public void deleteBookingItem(OrderItem order) {
		// TODO Auto-generated method stub
		orderRepo.deleteById(order.getId());
		Session session = entityManager.unwrap(Session.class);
		String sql = "delete from booking where order_id="+order.getId();
		//session.createNativeQuery(sql);
		Query<BookingOrder> qry = session.createNativeQuery(sql);
		qry.executeUpdate();
		System.out.println("order deleted successfully");
		
	}
	@Override
	public List<BookingOrder> getAllBookings() {
		// TODO Auto-generated method stub
		return bookingOrder.findAll();
	}
	@Override
	public BookingOrder getBooking(BookingOrder booking) {
		// TODO Auto-generated method stub
		Optional<BookingOrder> order= bookingOrder.findById(booking.getId());
		if(order!=null)
			return order.get();
		else
			return null;
	}
	@Override
	public List<RestaurantAndItemVO> getRestaurantsByRating(int price,int rating) {
		// TODO Auto-generated method stub
		List<RestaurantAndItemVO> restaurants = restaurantServiceDAO.getRestaurantsByRating(price,rating);
		return restaurants;
	}
	@Override
	public List<Restaurant> getRestaurantsByRegion(String region) {
		// TODO Auto-generated method stub
		return  restaurantServiceDAO.getRestaurantsByRegionWise(region);
	}
	@Override
	public List<BookingsByPrize> getBookingsByPrize() {
		// TODO Auto-generated method stub
		return restaurantServiceDAO.groupByPrizeForBooking();
	}
}
